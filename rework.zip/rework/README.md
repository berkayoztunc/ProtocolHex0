# GeniHero Rework Package (Phaser JS)

Bu klasör, Godot projesini başka bir motorda yeniden üretmek için hazırlanmış taşınabilir pakettir.

## İçerik

- `assets_visuals/`: Projedeki tüm görsel dosyaların kopyası (yol yapısı korunur)
- `ASSET_FILE_LIST.txt`: Kopyalanan tüm görsellerin tam listesi
- `AI_PORTING_BRIEF_PHASER.md`: Godot → Phaser mimari dönüşüm rehberi
- `AI_GAMEPLAY_SPEC.md`: Oynanış kuralları, formüller, sistem detayları
- `AI_IMPLEMENTATION_BACKLOG_PHASER.md`: AI ajanı için adım adım uygulama sırası

## Notlar

- Bu klasördeki dosyalar kopyadır; orijinal proje dosyaları yerinde durur.
- Görseller kopyalanırken proje içindeki göreli yollar korunmuştur.
- Sayım: `382` görsel dosya.

## Hızlı doğrulama

```bash
cd rework
wc -l ASSET_FILE_LIST.txt
find assets_visuals -type f | wc -l
```

Her iki komut da aynı değeri vermelidir.
