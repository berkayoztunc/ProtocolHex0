# Phaser Reimplementation Backlog (AI-Executable)

Use this as an ordered task list for an autonomous coding AI.

## Phase 0 - Project Bootstrap

- Create Phaser 3 + TypeScript project.
- Add folders:
  - `src/scenes`
  - `src/systems`
  - `src/entities`
  - `src/config`
  - `src/ui`
  - `src/services`
- Add JSON config files mirroring current gameplay config.
- Add asset loader that scans `assets_visuals/assets/**` path map.

## Phase 1 - Vertical Slice (Must Pass)

- Implement player movement + dash.
- Implement 1 enemy spawn type (runner).
- Implement plasma rifle basic auto-fire.
- Implement enemy death + XP drop + XP pickup.
- Implement level up event + simple perk selection UI (3 options).
- Implement health/xp HUD bars and kill counter.

Exit criteria:

- 5-minute playable loop without fatal errors.

## Phase 2 - Full Combat Systems

- Add all passive weapons.
- Add held weapon slot system (1..5).
- Add projectile classes (`standard/aoe/bouncing/beam`).
- Add targeting mode cycling (`forward/rear_guard/side_sweep/full_spread/orbital_fire`).

Exit criteria:

- Weapon unlocks and cooldown/readiness behave as specified.

## Phase 3 - Enemy Expansion

- Add all 10 enemy archetypes.
- Add behavior-specific movement logic.
- Add ranged fire profiles for skirmisher/sniper/mortar/suppressor.
- Add resistances and scaling.

Exit criteria:

- Spawn mix evolves with kills/time and remains balanced.

## Phase 4 - Economy + Meta

- Add chest spawn and reward logic.
- Add perk costs, prerequisites, and stack caps.
- Add run-state persistence and continue flow from start menu.

Exit criteria:

- Full round-trip: start -> progress -> die -> continue.

## Phase 5 - Polish/Parity

- Add SFX/VFX hooks.
- Refine UI state transitions and notifications.
- Optimize pools and collision passes.
- Verify parity checklist from `AI_PORTING_BRIEF_PHASER.md`.

## Non-Goals for Initial Port

- New game design
- New progression model
- Visual redesign
- Multiplayer/networking

## Deliverables for Each Phase

- Code
- Short changelog
- Known issues list
- Quick verification steps
