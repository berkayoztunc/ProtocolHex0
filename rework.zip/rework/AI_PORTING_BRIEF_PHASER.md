# AI Porting Brief: Godot -> Phaser 3

## 1) Goal

Rebuild the current GeniHero gameplay in Phaser 3 (JavaScript/TypeScript) while preserving:

- Core survival loop
- Progression pacing
- Weapons/perks behavior
- Enemy archetype behavior
- HUD and run-state continuity

## 2) Target Stack

- Runtime: Phaser 3
- Language: TypeScript preferred (JS acceptable)
- Physics: Arcade Physics
- Data source: JSON config files (mirror current config values)

## 3) Canonical Engine Mapping

### Godot -> Phaser mapping

- `Node2D/CharacterBody2D` -> `Phaser.GameObjects.Sprite` (+ physics body)
- `Timer` -> Scene `time.addEvent`
- `signals` -> custom event bus (`Phaser.Events.EventEmitter`)
- `groups` -> `physics.add.group` / `add.group`
- `autoload singleton (ConfigService/Session)` -> app-level services (`ConfigService`, `RunSessionService`)
- `PackedScene.instantiate()` -> prefab/factory functions

## 4) Required Phaser Scene Layout

- `BootScene`: preload assets and config
- `StartMenuScene`: player name, continue/new run
- `GameScene`: all gameplay systems
- `UIScene` (optional but recommended): HUD/perk overlay/game over

## 5) Systems to Implement (Priority)

1. `PlayerSystem`
2. `EnemySpawnSystem`
3. `EnemyAISystem` (10 archetypes + ranged fire profiles)
4. `ProjectileSystem` (standard/aoe/bouncing/beam)
5. `WeaponSystem` (passive + active slot weapons)
6. `PerkSystem` (catalog, prerequisites, stack limits, costs)
7. `PickupSystem` (xp gems/chest)
8. `HUDSystem`
9. `RunStatePersistenceSystem`

## 6) Update Order (single frame)

1. Read input
2. Update player movement/dash
3. Update player fire logic (passive + held)
4. Update enemy spawn timer + spawn
5. Update enemy AI + enemy fire
6. Update projectiles + collisions
7. Resolve drops and collection
8. Apply XP/level/perk events
9. Refresh HUD
10. Autosave snapshot (interval-based)

## 7) Data-Driven Rules (must stay external)

Keep these in JSON (not hard-coded):

- Difficulty knobs (spawn interval, growth, elite chance)
- Enemy archetypes and fire profiles
- Weapon definitions
- Targeting modes
- Upgrade costs and max stacks
- XP and chest drop settings

## 8) Migration Constraints

- Preserve current feel over visual polish.
- Keep deterministic formulas equivalent to current values.
- Don’t redesign systems during first port.
- First milestone = feature parity, second milestone = refactor/optimization.

## 9) Known Inconsistency to Normalize

Current code contains mixed level defaults (`HUD init` implies level 1, player variable appears as level 20 in script state). For Phaser parity build, normalize new run start as **level 1** unless explicit save-state restore exists.

## 10) Acceptance Criteria

A build is considered parity-ready when:

- New run playable from menu
- Enemies spawn and scale over time/kills
- XP levels up and perk selection works
- Passive/active weapons function with cooldown/readiness
- Chest rewards and projectile class unlock flow works
- Game over and continue flow persist run data
