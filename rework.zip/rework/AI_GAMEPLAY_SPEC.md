# GeniHero Gameplay Specification (for AI Re-implementation)

This document defines the gameplay canon to reproduce in Phaser.

## 1) Core Loop

1. Player moves in arena.
2. Enemies spawn continuously around player.
3. Player auto-fires passives + can activate held weapons by slot key.
4. Killed enemies drop XP and sometimes chest.
5. XP -> level up -> perk point gain -> perk selection.
6. Difficulty ramps by time + kills.
7. Player death ends run; run snapshot remains for continue.

## 2) Controls

- Move: `WASD` or arrow keys
- Dash: `Shift`
- Bomb: `Q`
- Heal charge: `E`
- Cycle targeting mode: `Tab`
- Cycle projectile class: `C` (if unlocked alternatives exist)
- Activate held slots: `1..5`
- Open/close perk tree: `P`

## 3) Difficulty and Spawn Formulas

### Spawn interval tuning

- Base: `1.7`
- Min: `0.42`
- Every `10` kills: `spawn_interval -= 0.07` (clamped to min)

### Difficulty progress scalar

`progress = (kill_count / 30.0) * enemy_health_growth + (elapsed_seconds / 300.0)`

where `enemy_health_growth = 0.09` (config default)

### Elite chance

`eliteChance = clamp(base + minutes * perMinute, base, max)`

- base = `0.03`
- perMinute = `0.015`
- max = `0.2`

## 4) Enemy Archetypes (10)

Each archetype is data-driven via config fields:

- `unlock_kills`, `unlock_seconds`, `spawn_weight`
- `base_health`, `base_speed`, `base_damage`
- `physical_resistance`, `explosive_resistance`
- `behavior` (runner/tank/charger/zigzag/shielded/skirmisher/sniper/mortar/suppressor/juggernaut)
- `is_ranged`, `fire_profile_id`

Unlock mode is `hybrid_or` by default:

- unlocked if `kill_count >= unlock_kills OR elapsed_seconds >= unlock_seconds`

Weighted selection:

- Build available archetype set
- Compute effective weight with unlock progress ramp
- Roll weighted random

## 5) XP and Chest Economy

### XP tiers

- Weights: small `65`, medium `25`, large `10`
- Medium unlocked after `20` kills
- Large unlocked after `45` kills
- Luck modifies medium/large weights

### Chest spawn

- Guaranteed cadence check: every `15` kills
- Random chance: `0.08` (+ luck factor)
- Max alive chest count: `2`

### Chest rewards

- `heal` (30% max hp)
- `shield`
- `magnet`
- `bomb`
- `perk_points` (1/2/3 roll)

## 6) Weapon Model

## 6.1 Passive weapons

- `plasma_rifle` (starter)
- `nano_swarm`
- `tesla_emitter`
- `scatter_cannon`
- `orbital_sentinel`

## 6.2 Held slot weapons

- Slot 1: `railgun`
- Slot 2: `void_launcher`
- Slot 3: `arc_blaster`
- Slot 4: `phase_disruptor`
- Slot 5: `gravity_pulse`

Held weapons have:

- `active_duration_sec`
- `active_cooldown_sec`
- own projectile behavior
- temporary override of current held weapon

## 6.3 Projectile classes

- `standard` (default)
- `aoe` (unlock)
- `bouncing` (unlock)
- `beam` (unlock)

## 6.4 Targeting modes

- `forward`
- `rear_guard`
- `side_sweep`
- `full_spread`
- `orbital_fire`

## 7) Perk System Canon

Perk catalog is prerequisite-driven and stack-limited.

Apply these rules:

- Offer only perks meeting prerequisites
- Respect max stack caps
- Cost = `base_cost * (current_stack + 1)`
- On level-up: +1 perk point
- Selecting perk consumes points and applies immediate stat/system effect

Main categories:

- Combat
- Targeting
- Projectile unlocks
- Passive weapon unlock/upgrade
- Active weapon unlock/upgrade
- Defense / Utility / Mobility

## 8) HUD Requirements

Must show at least:

- Health bar
- XP bar
- Level
- Kill count
- Perk points
- Active/held weapon display (including readiness/cooldown state)
- Current targeting mode
- Current projectile class

## 9) Persistence (Run Continuation)

Persist last run snapshot (JSON/local storage):

- level, xp, max health, current health
- unlocked weapons / targeting / projectile classes
- upgrade stacks
- perk points
- kill count

Continue flow should restore this snapshot to resume session.

## 10) Phaser-specific Implementation Notes

- Use object pools for projectiles and floating numbers.
- Keep enemy AI and weapon definitions table-driven from JSON.
- Keep combat numbers deterministic first; visual effects second.
- Preserve update order consistency to avoid desync in cooldown/ready UI.
